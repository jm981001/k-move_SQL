create table member(
    tel varchar(11) primary key,
    menu varchar2(50) not null,
    points varchar2(3) not null,
	reg_date date not null,
    FOREIGN KEY(menu) REFERENCES coffee(menu),
    FOREIGN KEY(points) REFERENCES coffee(su),
    FOREIGN KEY(points) REFERENCES dessert(su)
);

insert into member
     values ('admin', 'admin', '�̼���', 'aaaaaa@naver.com',sysdate);
