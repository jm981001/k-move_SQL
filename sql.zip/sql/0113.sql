--Ʈ���� ����

CREATE TABLE AA --��ǰ
( AANO NUMBER(4) CONSTRAINT aa_aano_pk PRIMARY KEY,
  AANAME VARCHAR2(30),
  JEGO NUMBER(4));
  
CREATE TABLE BB --�ֹ�
( BBNO NUMBER(4) CONSTRAINT bb_bbno_pk PRIMARY KEY,
  BBNAME VARCHAR2(30),
  SU NUMBER(4),
  AANO NUMBER(4) CONSTRAINT bb_aano_fk REFERENCES AA);
  
INSERT INTO AA VALUES (1, '��ǰ1', 5);
INSERT INTO AA VALUES (2, '��ǰ2', 5);

INSERT INTO BB VALUES (1, '�ֹ�1', 3, 2);
INSERT INTO BB VALUES (2, '�ֹ�2', 2, 1);

select * from aa;
select * from bb;

CREATE OR REPLACE TRIGGER trg_upd_aa
after insert --Ÿ�̹� / �̺�Ʈ
on bb --���
for each row
BEGIN
    update aa
    set aa.jego = (aa.jego - :new.su)
    where aa.aano = :new.aano;
END;
/
